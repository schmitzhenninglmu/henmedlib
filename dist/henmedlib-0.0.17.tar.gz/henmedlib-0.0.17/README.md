# henmedlib

This package projected started in the advent of my PhD. It's initial purpose was to serve as a python package 
encapsulating all functions that I may want to recycle at some point during my PhD. The package is structured
with the subfolders *i_o* (input-output, which contains different reading and writing functions) and *functions* (
containing all the other functions). Within the files the functions are sorted alphabetically.
The source code is available on [henmedlib](https://github.com/schmitzhenninglmu/henmedlib). 
Comments and improvements are highly appreciated. 
