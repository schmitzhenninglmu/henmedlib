__author__ = "Henning Schmitz"


def test():
    print('This is a test.')
    
