__author__ = "Henning Schmitz"

#Subpackage containing the input and output functions

name = "henmedlib.i_o"

from .dicom import *
from .mha import *
