__author__ = "Henning Schmitz"

name = "henmedlib.functions"